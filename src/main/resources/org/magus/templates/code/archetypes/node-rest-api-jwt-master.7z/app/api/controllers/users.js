const fs = require('fs');
const userModel = require('../models/users');
const bcrypt = require('bcryptjs');	
const jwt = require('jsonwebtoken');				

module.exports = {
	create: function(req, res, next) {
		console.log('---------------------');
		console.log(req.body);
		userModel.create({ name: req.body.name, email: req.body.email, password: req.body.password }, function (err, result) {
				  if (err) 
				  	next(err);
				  else
				  	res.json({status: "success", message: "User added successfully!!!", data: null});
				  
				});
	},

	logout: function(req, res) {
		res.status(200).send({ auth: false, token: null });
	  },
	  

	authenticate: function(req, res, next) {
		console.log(req.body);
		userModel.findOne({email:req.body.email}, function(err, userInfo){
					if (err) {
						next(err);
					} else {
							console.log(userInfo);
						if(userInfo != null && bcrypt.compareSync(req.body.password, userInfo.password)) {
							console.log('getting private key');
							var privateKey  = fs.readFileSync('./private.key', 'utf8');
						 const token = jwt.sign({id: userInfo._id}, privateKey, { 
							 expiresIn: 300, // 5min 
							 algorithm:  "RS256" //SHA-256 hash signature
						 }); 

						 console.log(token);

						 //res.json({status:"success", message: "user found!!!", data:{user: userInfo, token:token}});	
						 //res.setHeader('Set-Cookie', ['token' + token + '; HttpOnly']);
						 //res.redirect('/');

						 res.cookie('token', token, { 
							httpOnly: true,
							// secure: true // - for secure, https only cookie
						});
						res.render('index', {token});

						}else{

							res.json({status:"error", message: "Invalid email/password!!!", data:null});

						}
					}
				});
	},

}					

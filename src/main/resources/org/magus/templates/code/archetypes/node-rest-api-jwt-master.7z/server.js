const fs = require('fs');
const express = require('express');
const session = require('express-session')  
const logger = require('morgan');
const index = require('./routes/index') ;
const movies = require('./routes/movies') ;
const users = require('./routes/users');
const bodyParser = require('body-parser');
const mongoose = require('./config/database'); //database configuration
const app = express();

var path = require('path');
var cookieParser = require('cookie-parser');
var jwt = require('jsonwebtoken');

app.set('secretKey', 'nodeRestApi'); // jwt secret token

// connection to mongodb
mongoose.connection.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.use(logger('dev'));
app.use(bodyParser.urlencoded({extended: false}));

/*
app.get('/', function(req, res){
res.json({"tutorial" : "Build REST API with node.js"});
});*/

app.use('/', index);


// public route
app.use('/users', users);

// private route
app.use('/movies', validateUser, movies);

app.set('views', path.join(__dirname, 'app/views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/favicon.ico', function(req, res) {
    res.sendStatus(204);
});

function validateUser(req, res, next) {
  console.log('*******VALIDATEUSER');
  console.log(req.headers['x-access-token']);
  var publicKey  = fs.readFileSync('./public.key', 'utf8');
  jwt.verify(req.headers['x-access-token'], publicKey, {algorithm: ["RS256"]}, function(err, decoded) {
    if (err) {
      console.log('ERRRRRRRRRRRR')
      res.json({status:"error", message: err.message, data:null});
    }else{
      // add user id to request
      console.log(decoded);
      req.body.userId = decoded.id;
      next();
    }
  });
  
}


// express doesn't consider not found 404 as an error so we need to handle 404 it explicitly
// handle 404 error
app.use(function(req, res, next) {
	let err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// handle errors
app.use(function(err, req, res, next) {
	console.log(err);
	
  if(err.status === 404)
  	res.status(404).json({message: "Not found"});
  else	
    res.status(500).json({message: "Something looks wrong :( !!!"});

});

app.listen(3000, function(){
	console.log('Node server listening on port 3000');
});

const express = require('express');
const router = express.Router();
const userController = require('../app/api/controllers/users');

router.get('/', function(req, res, next) {
    res.render('login', { title: 'Login', message: null });
});
  
router.get('/index', function(req, res, next) {
    res.render('index', { title: 'Index', message: null });
});

module.exports = router;